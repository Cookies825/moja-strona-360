var APP_DATA = {
  "scenes": [
    {
      "id": "0-pic_20250819_095345_20250821083954",
      "name": "PIC_20250819_095345_20250821083954",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 960,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.3365071038314758
      },
      "linkHotspots": [
        {
          "yaw": -0.436345002904158,
          "pitch": 0.36522160752275035,
          "rotation": 0,
          "target": "0-pic_20250819_095345_20250821083954"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0,
          "pitch": 0,
          "title": "Robot",
          "text": "Służy do transportowania przedmiotów do 250kg"
        },
        {
          "yaw": 0,
          "pitch": 0,
          "title": "Title",
          "text": "Text"
        },
        {
          "yaw": -0.1758124417017939,
          "pitch": 0.1984950281829807,
          "title": "Robot",
          "text": "Text"
        }
      ]
    },
    {
      "id": "1-pic_20250819_133453_20250819134216",
      "name": "PIC_20250819_133453_20250819134216",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        },
        {
          "tileSize": 512,
          "size": 4096
        }
      ],
      "faceSize": 2640,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.1601218051621665,
          "pitch": -0.09230806509311051,
          "rotation": 0,
          "target": "0-pic_20250819_095345_20250821083954"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.7306879303496245,
          "pitch": 0.00030553724053916653,
          "title": "TV",
          "text": "Telewizor"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
